# tfm
Código del TFM

Se recogen los scripts utilizados en el estudio así como el material suplementario formado por tablas y figuras. Nótese que se usan varios scripts como en el caso de los s04... para agilizar el tiempo de ejecución. De esta manera podíamos ejecutarlos paralelamente en el servidor del CIPF (Tuvimos que hacerlo debido a la gran cantidad de tiempo que tardaban en ejecutarse).
